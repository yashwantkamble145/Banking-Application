package com.yashwant;

public class Main {

	 public static void main(String[] args) {

	        Account yashwantAccount = new Account("121212",0,"Yashwant","Yash@xyz.com","1212121");

	        yashwantAccount.DepositMoney(50);
	        yashwantAccount.DepositMoney(150);

	        yashwantAccount.WithDrawMoney(100);
	    
	    }
	}
